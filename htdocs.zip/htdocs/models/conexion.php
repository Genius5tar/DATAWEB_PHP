<?php
$conexion=new mysqli("localhost","root","","data_crud");
$conexion->set_charset("utf8");


?>